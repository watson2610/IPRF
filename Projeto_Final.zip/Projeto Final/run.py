from app import app

if __name__ == '__main__':
    app.run()
    #Questão de segurança, verifica se apenas o arquivo principal esta sendo executados, ele não executa secundarios